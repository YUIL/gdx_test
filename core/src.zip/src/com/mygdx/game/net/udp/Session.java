package com.mygdx.game.net.udp;

import java.net.SocketAddress;
import java.util.LinkedList;
import java.util.Queue;


public class Session {
	long id;
	int timeOut=100;

	public short getTimeOutMultiple() {
		return timeOutMultiple;
	}

	public void setTimeOutMultiple(short timeOutMultiple) {
		this.timeOutMultiple = timeOutMultiple;
	}

	short timeOutMultiple=0;
	long lastSendTime;
	SocketAddress contactorAddress;
	byte state;
	UdpMessage currentSendMessage;
	volatile UdpMessage lastSendMessage;
	UdpMessage lastRecvMessage;
	volatile Queue<UdpMessage> recvMessageQueue;

	public Session(long id){
		this.id=id;
		this.setLastSendMessage(new UdpMessage(id, -1));
		this.setLastRecvMessage(new UdpMessage(id, -1));
		recvMessageQueue=new LinkedList<UdpMessage>();
	
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}
	public SocketAddress getContactorAddress() {
		return contactorAddress;
	}
	public void setContactorAddress(SocketAddress contactorAddress) {
		this.contactorAddress = contactorAddress;
	}
	public byte getState() {
		return state;
	}
	public void setState(byte state) {
		this.state = state;
	}
	public UdpMessage getCurrentSendMessage() {
		return currentSendMessage;
	}
	public void setCurrentSendMessage(UdpMessage currentSendMessage) {
		this.currentSendMessage = currentSendMessage;
	}
	public synchronized UdpMessage getLastSendMessage() {
		return lastSendMessage;
	}
	public synchronized void setLastSendMessage(UdpMessage lastSendMessage) {
		this.lastSendMessage = lastSendMessage;
	}
	public long getLastSendTime() {
		return lastSendTime;
	}
	public void setLastSendTime(long lastSendTime) {
		this.lastSendTime = lastSendTime;
	}
	public   Queue<UdpMessage> getRecvMessageQueue() {
		return recvMessageQueue;
	}
	public   void setRecvMessageQueue(Queue<UdpMessage> recvMessageQueue) {
		this.recvMessageQueue = recvMessageQueue;
	}
	public UdpMessage getLastRecvMessage() {
		return lastRecvMessage;
	}
	public void setLastRecvMessage(UdpMessage lastRecvMessage) {
		this.lastRecvMessage = lastRecvMessage;
	}
	
	
	public synchronized UdpMessage currentSendUdpMessage(UdpMessage message){
		if (message==null){
			return this.currentSendMessage;
		}else{
			this.currentSendMessage=message;
			return null;
		}
		
	}

	@Override
	public String toString() {
		return "Session{" +
				"id=" + id +
				", timeOut=" + timeOut +
				", lastSendTime=" + lastSendTime +
				", contactorAddress=" + contactorAddress +
				", state=" + state +
				", currentSendMessage=" + currentSendMessage +
				", lastSendMessage=" + lastSendMessage +
				", lastRecvMessage=" + lastRecvMessage +
				", recvMessageQueue=" + recvMessageQueue +
				'}';
	}
}
