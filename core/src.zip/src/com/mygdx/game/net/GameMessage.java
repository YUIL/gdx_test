package com.mygdx.game.net;

public class GameMessage {

}
