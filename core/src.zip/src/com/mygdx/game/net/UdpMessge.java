package com.mygdx.game.net;

public class UdpMessge {
	public int  sequenceId;
	public int type;
	public int lenth;
	public byte[]data;
}
