package com.mygdx.game.net.udp2;

/**
 * Created by i008 on 2015/8/27.
 */
public class UdpServer {

}
