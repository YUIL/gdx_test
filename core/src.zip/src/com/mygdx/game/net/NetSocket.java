package com.mygdx.game.net;

/**
 * Created by i008 on 2015/8/27.
 */
public interface NetSocket {

}
