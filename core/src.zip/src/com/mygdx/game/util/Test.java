package com.mygdx.game.util;

public interface Test {
int a=1;
}
