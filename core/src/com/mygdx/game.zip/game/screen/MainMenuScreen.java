package com.mygdx.game.screen;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.gui.GuiFactory;
import com.mygdx.game.inputprocessor.InputProcessor;

public class MainMenuScreen implements Screen {
	Game game;
	SpriteBatch batch;
	BitmapFont font;
	Skin skin;
	Stage stage;
	GuiFactory guiFactory;
	public MainMenuScreen(Game game){
		
		this.game=game;
		batch=new SpriteBatch();
		font=new BitmapFont();
		stage=new Stage(new ScreenViewport());
		guiFactory=new GuiFactory();
	
		skin=new Skin(Gdx.files.internal("data/uiskin.json"));
		guiFactory.setStageFromXml(stage,"data/MainMenuGui.xml" , skin);
		inputProcess();
	
		
		Button b=new Button(skin);
		b.addListener(new InputListener(){
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	System.out.println("asd");
		        return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		
		stage.addActor(b);
		Gdx.input.setInputProcessor(stage);
		System.out.println(stage.getRoot().findActor("MainMenu").getX());

	}
	@Override
	public void show() {
		// TODO Auto-generated method stub

	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		Gdx.gl.glViewport(0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT|GL20.GL_DEPTH_BUFFER_BIT);
		
		stage.act(delta);	
		stage.draw();
		
		InputProcessor.handleInput(game);
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		stage.getViewport().update(width, height, true);
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

		font.dispose();
		batch.dispose();
		stage.dispose();
		skin.dispose();
	
	}
	public void  inputProcess(){
		System.out.println("s");
		stage.getRoot().findActor("MainMenu").addListener(new InputListener() {
		    public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
		    	game.setScreen(new MainMenuScreen(game));
		    	System.out.println("asd");
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		stage.getRoot().findActor("ShapeTest").addListener(new InputListener() {
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	game.setScreen(new ShapeTestScreen(game));
		    	return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		stage.getRoot().findActor("ModelLoad").addListener(new InputListener() {
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	game.setScreen(new ModelLoadScreen(game));
		        return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		stage.getRoot().findActor("ShaderTest").addListener(new InputListener() {
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	//game.setScreen(new ShaderTest2Screen(game));
		        System.out.println("这个暂时不能用");
		    	return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		stage.getRoot().findActor("ShaderTest2").addListener(new InputListener() {
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	game.setScreen(new ShaderTest2Screen(game));
		        return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
		stage.getRoot().findActor("FrustumCullingTest").addListener(new InputListener() {
		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		    	game.setScreen(new FrustumCullingTestScreen(game));
		        return;
		    }
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        return true;
		    }
		});
	}

}
