package com.mygdx.game.gui;

import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.ArrayMap;

public class ListenerAdapter {
	ArrayMap<String,InputListener > listenerMap;
	
}
