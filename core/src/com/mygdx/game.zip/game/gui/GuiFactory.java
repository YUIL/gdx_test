package com.mygdx.game.gui;

import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Button.ButtonStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class GuiFactory {
	SAXReader reader;
	public GuiFactory(){
		reader = new SAXReader();
		reader.setEncoding("utf-8");
	}
	//从XML中解析一个Stage对象
	public Stage getStageFromXml(String xmlPath) {
		Stage stage = new Stage(new ScreenViewport());
		try {
			Document document = reader.read(Gdx.files.internal(xmlPath).read());
			Element root = document.getRootElement();
			List<?> nodes = root.elements("actor");
			for (Iterator<?> it = nodes.iterator(); it.hasNext();) {
				Element actorElm = (Element) it.next();
				String type = actorElm.attributeValue("type");
				switch (type) {
				case "button":
					Drawable up = getDrawable(actorElm.element("up"));
					Drawable down = getDrawable(actorElm.element("down"));
					Button button = new Button(up, down);
					setActorAttribute(button, actorElm);
					stage.addActor(button);
					break;

				default:
					break;
				}
			}
			return stage;
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//从XML中读取并配置一个Actor对象
	public void setStageFromXml(Stage stage,String xmlPath ,Skin skin){
		
		try {
			Document document= reader.read(Gdx.files.internal(xmlPath).read());
			Element root = document.getRootElement();
			
			List<?>nodes=root.elements("actor");
			for (Iterator<?> it=nodes.iterator();it.hasNext();){
				Element actorElm=(Element)it.next();
				String type=actorElm.attributeValue("type");
				Element skinElm=actorElm.element("skin");
				switch (type) {
				case "button":
					Button button;
					if(skinElm!=null){
						button=new Button(skin.get(skinElm.attributeValue("name"), ButtonStyle.class));
					}else{
						Drawable up = getDrawable(actorElm.element("up"));
						Drawable down = getDrawable(actorElm.element("down"));
						button = new Button(up, down);
					}
					
					setActorAttribute(button, actorElm);
					stage.addActor(button);
					break;
				case  "textButton":
					TextButton textButton;
					if(skinElm!=null){
						textButton=new TextButton(actorElm.attributeValue("name"),skin.get(skinElm.attributeValue("name"),TextButtonStyle.class));
						setActorAttribute(textButton, actorElm);
						stage.addActor(textButton);
					}else{
						System.err.println("不能缺少skin元素！");
					}
					
					break;
				default:
					break;
				}
			}
		} catch (DocumentException e) {
			// TODO Auto-generated catch block.
			System.err.println("gui.XML文档有问题！");
			e.printStackTrace();
		}
		
	}
	
	//从Element中解析一个Drawble对象
	protected Drawable getDrawable(Element elm) {
		return new TextureRegionDrawable(new TextureRegion(new Texture(
				Gdx.files.internal(elm.element("path").getText())),
				Integer.parseInt(elm.element("x").getText()),
				Integer.parseInt(elm.element("y").getText()),
				Integer.parseInt(elm.element("w").getText()),
				Integer.parseInt(elm.element("h").getText())));
	}
	//从Element中读取并设置actor的一般属性
	protected void setActorAttribute(Actor actor,Element actorElm){
		actor.setX(Float.parseFloat(actorElm.element("x").getText()));
		actor.setY(Float.parseFloat(actorElm.element("y").getText()));
		actor.setName(actorElm.attributeValue("name"));
	}
}
